package org.androdevlinux.spectrum.data

import android.location.Location
import androidx.lifecycle.MutableLiveData

class Constant {
    companion object {
        const val BASE_URL = "https://test.privatespectrum.xyz"
    }
}

