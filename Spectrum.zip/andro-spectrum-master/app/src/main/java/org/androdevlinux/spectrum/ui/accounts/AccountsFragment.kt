package org.androdevlinux.spectrum.ui.accounts

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import dagger.hilt.android.AndroidEntryPoint
import org.androdevlinux.spectrum.data.PreferenceProvider
import org.androdevlinux.spectrum.data.model.AddressResponse
import org.androdevlinux.spectrum.data.network.Resource
import org.androdevlinux.spectrum.databinding.FragmentAccountsBinding
import javax.inject.Inject

@AndroidEntryPoint
class AccountsFragment : Fragment() {

    private var _binding: FragmentAccountsBinding? = null
    private val viewModel by viewModels<AccountsViewModel>()

    private val binding get() = _binding!!

    @Inject
    lateinit var pref: PreferenceProvider

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        _binding = FragmentAccountsBinding.inflate(inflater, container, false)
        viewModel.address.observe(viewLifecycleOwner) { handleResponse(it) }
        return binding.root
    }

    private fun handleResponse(res: Resource<AddressResponse>) {
        when (res) {
            is Resource.Success -> res.value.address?.let {
//                binding.account.text = it
            }

            is Resource.Failure -> println(res.errorBody)

        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        pref.getSeedPhrase()?.let { viewModel.getAddress("1", it) }
    }
}